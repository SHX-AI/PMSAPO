import tensorflow as tf
import os
import datetime
import numpy as np
from Settings import Config
from Dataset import Dataset
from network_PMSAPO521 import MM
import pickle
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
import logging
import threading
import queue
import datetime
import time
import gc
from collections import OrderedDict
from scipy.sparse import csr_matrix
import warnings
#警告删除，如果需要可以删掉查看

warnings.filterwarnings("ignore", category=FutureWarning)

logging.getLogger('tensorflow').disabled = True

os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_boolean('train',True, 'set True to train')
# 第二篇



# traindata = pickle.load(open('E:\dataset\mosi/m21train.pkl', 'rb'))
traindata = pickle.load(open('E:\\dataset\\mosi/2/train2.pkl', 'rb'))
testdata = pickle.load(open('E:\\dataset\\mosi/2/test2-0.5.pkl', 'rb'))
# testdata = pickle.load(open('E:\dataset/mosi/m11test.pkl', 'rb'))
#2-5
print("先看settings改没改")

def evaluation(y_pred, y_true):
    f1_s = f1_score(y_true, y_pred, average='macro')
    accuracy_s = accuracy_score(y_true, y_pred)
    return f1_s, accuracy_s


def is_equal(a, b):
    flag = 1
    for i in range(len(a)):
        if a[i] != b[i]:
            flag = 0
            break
    return flag

class DynamicWarmupScheduler:
    def __init__(self, initial_warmup_steps, learning_rate_base, patience, improvement_threshold=0.01, decay_factor=0.9, increase_factor=1.1, min_warmup_steps=1077):
        self.initial_warmup_steps = min(initial_warmup_steps, 77777)
        self.learning_rate_base = learning_rate_base
        self.patience = patience
        self.improvement_threshold = improvement_threshold
        self.decay_factor = decay_factor  # 减小因子
        self.increase_factor = increase_factor  # 增加因子
        self.min_warmup_steps = min_warmup_steps
        self.best_loss = float('inf')
        self.no_improvement_steps = 0

    def get_learning_rate(self, global_step):
        learning_rate = self.learning_rate_base * tf.minimum(1.0, tf.cast(global_step / self.initial_warmup_steps, tf.float32))
        return learning_rate

    def update(self, current_loss, global_step):
        if current_loss < self.best_loss * (1 - self.improvement_threshold):
            self.best_loss = current_loss
            self.no_improvement_steps = 0
            # 当模型性能提升显著时，逐步减小 warmup steps，但不低于 min_warmup_steps
            self.initial_warmup_steps = max(int(self.initial_warmup_steps * self.decay_factor), self.min_warmup_steps)
            self.initial_warmup_steps = min(self.initial_warmup_steps, 77777)  # 添加限制最大上限为777,777
            print("Reduced warmup steps to:", self.initial_warmup_steps)
        else:
            self.no_improvement_steps += 1

            if self.no_improvement_steps >= self.patience:
                # 当多次没有改进时，逐步增加 warmup steps
                self.initial_warmup_steps = int(self.initial_warmup_steps * self.increase_factor)
                self.initial_warmup_steps = min(self.initial_warmup_steps, 77777)  # 添加限制最大上限为777,777
                print("Increased warmup steps to:", self.initial_warmup_steps)
                self.no_improvement_steps = 0


# 学习率预热函数定义
def learning_rate_warmup(learning_rate_base, global_step, warmup_steps):
    return learning_rate_base * tf.minimum(1.0, tf.cast(global_step / warmup_steps, tf.float32))


class AdamWOptimizer(tf.train.Optimizer):
    def __init__(self, learning_rate, weight_decay, use_locking=False, name="AdamW"):
        super(AdamWOptimizer, self).__init__(use_locking, name)
        self._learning_rate = learning_rate
        self._weight_decay = weight_decay

    def _apply_dense(self, grad, var):
        grad_with_decay = grad + self._weight_decay * var
        return tf.train.AdamOptimizer(self._learning_rate).apply_gradients([(grad_with_decay, var)])

    def _apply_sparse(self, grad, var):
        grad_with_decay = grad + self._weight_decay * var
        return tf.train.AdamOptimizer(self._learning_rate).apply_gradients([(grad_with_decay, var)])


class MAMLPPOnlineLearning:
    def __init__(self, model, sess, initial_learning_rate=0.001, meta_learning_rate=0.0005, decay_rate=0.995,
                 accumulation_steps=10, l2_reg=0.001):
        self.model = model
        self.sess = sess
        self.initial_learning_rate = initial_learning_rate
        self.meta_learning_rate = meta_learning_rate
        self.decay_rate = decay_rate
        self.accumulation_steps = accumulation_steps
        self.l2_reg = l2_reg
        self.step = 0
        self.consecutive_failures = 0
        self.max_consecutive_failures = 3
        self.best_f1 = 0.0
        self.best_accuracy = 0.0

        with tf.variable_scope('online_learning'):
            self.learning_rate = tf.Variable(initial_learning_rate, trainable=False, name='learning_rate')
            self.optimizer = tf.train.AdamOptimizer(self.learning_rate)
            self.meta_optimizer = tf.train.AdamOptimizer(self.meta_learning_rate)
            self.trainable_vars = model.get_trainable_vars()

            self.regularization = tf.add_n([tf.nn.l2_loss(v) for v in self.trainable_vars]) * self.l2_reg
            self.total_loss = model.total_loss + self.regularization

            self.gradients = tf.gradients(self.total_loss, self.trainable_vars)
            self.clipped_gradients, _ = tf.clip_by_global_norm(self.gradients, 5.0)
            self.accumulated_gradients = [tf.Variable(tf.zeros_like(tv), trainable=False, name=f'accum_grad_{i}')
                                          for i, tv in enumerate(self.trainable_vars)]
            self.zero_ops = [tv.assign(tf.zeros_like(tv)) for tv in self.accumulated_gradients]

            self.update_ops = []
            for var, grad in zip(self.trainable_vars, self.accumulated_gradients):
                self.update_ops.append(tf.assign_sub(var, self.learning_rate * grad / self.accumulation_steps))

            self.sample_weight = tf.placeholder(tf.float32, shape=(), name='sample_weight')
            self.weighted_loss = self.total_loss * self.sample_weight

            self.meta_gradients = tf.gradients(self.weighted_loss, self.trainable_vars)
            self.meta_update_ops = self.meta_optimizer.apply_gradients(zip(self.meta_gradients, self.trainable_vars))

    def update(self, feed_dict, sample_weight=1.0):
        self.step += 1
        current_lr = self.initial_learning_rate * (self.decay_rate ** (self.step / 5000))
        self.sess.run(tf.assign(self.learning_rate, current_lr))

        feed_dict[self.sample_weight] = sample_weight
        gradients = self.sess.run(self.clipped_gradients, feed_dict=feed_dict)
        self.sess.run([tf.assign_add(ac, grad) for ac, grad in zip(self.accumulated_gradients, gradients)])

        if self.step % self.accumulation_steps == 0:
            self.sess.run(self.update_ops)
            self.sess.run(self.zero_ops)

        return current_lr

    def meta_update(self, feed_dict):
        self.sess.run(self.meta_update_ops, feed_dict=feed_dict)

    def adjust_learning(self, pre_loss, post_loss):
        if post_loss >= pre_loss:
            self.consecutive_failures += 1
            if self.consecutive_failures >= self.max_consecutive_failures:
                self.initial_learning_rate *= 0.5
                self.consecutive_failures = 0
                print(f"连续{self.max_consecutive_failures}次失败, 学习率减半为: {self.initial_learning_rate}")
        else:
            self.consecutive_failures = 0
            if self.initial_learning_rate < 0.001:
                self.initial_learning_rate *= 1.1  # 如果效果好，稍微增加学习率
                print(f"学习率增加到: {self.initial_learning_rate}")

    def track_best_metrics(self, f1, accuracy):
        if f1 > self.best_f1:
            self.best_f1 = f1
        if accuracy > self.best_accuracy:
            self.best_accuracy = accuracy

        print(f"当前最佳 F1: {self.best_f1}, 当前最佳准确率: {self.best_accuracy}")

def train(sess, setting):
    sum = 0
    # 增添的
    scheduler = DynamicWarmupScheduler(initial_warmup_steps=setting.warmup_steps,
                                       learning_rate_base=setting.learning_rate,
                                       patience=10)
    for epoch in range(setting.epoch_num):
        for i in range(int(len(traindata['L']) / setting.batch_size)):
            sum = sum + 1
    print(sum)
    config = tf.ConfigProto()
    config.gpu_options.allow_growth = True
    config.gpu_options.per_process_gpu_memory_fraction = 0.9

    with tf.Session(config=config) as sess:
        dataset = Dataset()
        initializer = tf.contrib.layers.xavier_initializer()

        with tf.variable_scope('model', reuse=None, initializer=initializer):
            m = MM(is_training=True)

        global_step = tf.Variable(0, name='global_step', trainable=False)
        # learning_rate = learning_rate_warmup(setting.learning_rate, global_step, setting.warmup_steps)
        # learning_rate = learning_rate_warmup(setting.learning_rate, global_step, setting.warmup_steps)
        learning_rate = scheduler.get_learning_rate(global_step)

        optimizer = AdamWOptimizer(learning_rate, weight_decay=0.01)
        train_op = optimizer.minimize(m.total_loss, global_step=global_step)

        online_learning = MAMLPPOnlineLearning(m, sess)

        sess.run(tf.global_variables_initializer())

        var_list = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='model')
        saver = tf.train.Saver(var_list=var_list)

        online_learning_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='online_learning')
        sess.run(tf.variables_initializer(online_learning_vars))

        print("开始训练")


        total_steps = 2100
        initial_training_steps = 200000  # 初始训练阶段的步数
        online_update_frequency = 20  # 在线学习更新频率

        for step in range(total_steps):
            cur_batch = dataset.nextBatch(traindata, testdata, True)
            feed_dict = {
                m.visual: cur_batch['V'],
                m.audio: cur_batch['A'],
                m.text: cur_batch['T'],
                m.label: cur_batch['L'],
                m.flag: np.ones(setting.batch_size),
            }


            try:
                if step < initial_training_steps:
                    # 初始训练阶段
                    _, loss_ = sess.run([train_op, m.total_loss], feed_dict)
                else:
                    # 在线学习和元学习阶段
                    _, loss_ = sess.run([train_op, m.total_loss], feed_dict)

                    if step % online_update_frequency == 0:
                        sample_weight = 1.0 + 0.01 * (
                                    (step - initial_training_steps) / (total_steps - initial_training_steps))

                        pre_update_loss = sess.run(m.total_loss, feed_dict)
                        current_lr = online_learning.update(feed_dict, sample_weight)
                        post_update_loss = sess.run(m.total_loss, feed_dict)

                        print(f"在线学习更新完成 - 步骤: {step}, 学习率: {current_lr:.6f}")
                        print(f"更新前损失: {pre_update_loss:.4f}, 更新后损失: {post_update_loss:.4f}")

                        online_learning.adjust_learning(pre_update_loss, post_update_loss)
                        online_learning.meta_update(feed_dict)
                        print("MAML++元学习更新完成")
                        # ++
                scheduler.update(loss_, step)

                if step % 10 == 0:
                    time_str = datetime.datetime.now().isoformat()
                    tempstr = "{}: step {}, softmax_loss {:g}".format(time_str, step, loss_)
                    print(tempstr)
                    # 保存所有变量
                    saver_all = tf.train.Saver(max_to_keep=None)
                    path = saver_all.save(sess, './final/MT_ATT_model', global_step=step)
                    gc.collect()



            except tf.errors.ResourceExhaustedError:
                print("内存不足，尝试清理缓存并继续...")
                gc.collect()
                continue

        print("训练完成")









def test(sess, setting):
    dataset = Dataset()
    with sess.as_default():
        with tf.variable_scope('model', reuse=tf.AUTO_REUSE):
            mtest = MM(is_training=False)

        saver = tf.train.Saver()
        testlist = range(300, 2100, 10)
        # testlist = range(300, 1880, 10)
        best_model_iter = -1
        best_model_f1 = -1
        best_model_acc = -1

        all_f1 = []
        all_acc = []

        for model_iter in testlist:
            try:
                saver.restore(sess, './final/MT_ATT_model-' + str(model_iter))
            except tf.errors.NotFoundError:
                print(f"Model at iteration {model_iter} not found, skipping.")
                continue

            total_pred = []
            total_y = []

            num_batches = int(len(testdata['L']) / setting.batch_size)
            for i in range(num_batches):
                try:
                    cur_batch = dataset.nextBatch(traindata, testdata, FLAGS.train)

                    feed_dict = {
                        mtest.visual: cur_batch['V'],
                        mtest.audio: cur_batch['A'],
                        mtest.text: cur_batch['T'],
                        mtest.label: cur_batch['L'],
                        mtest.flag: np.ones(setting.batch_size)
                    }

                    prob = sess.run(mtest.prob, feed_dict)

                    predicted_labels = np.argmax(prob, axis=1)

                    total_pred.extend(np.argmax(prob, axis=-1))
                    total_y.extend(cur_batch['L'])
                except Exception as e:

                    continue

            try:
                f1, accuracy = evaluation(total_pred, total_y)
            except Exception as e:

                continue

            with open(r'C:\Users\abc\Desktop\Final222.txt', 'a') as file:
                all_f1.append(f1)
                all_acc.append(accuracy)

                if f1 > best_model_f1:
                    best_model_f1 = f1

                if accuracy > best_model_acc:
                    best_model_acc = accuracy
                    best_model_iter = model_iter

                time_str = datetime.datetime.now().isoformat()
                print(f"{time_str}")

                # 打印到控制台
                print('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥')
                print('model_iter:', model_iter)
                print('f1 score:', f1)
                print('accuracy score:', accuracy)
                print('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥')
                print('----------------------------')
                print('now best model_iter', best_model_iter)
                print('now best f1 score: ', best_model_f1)
                print('now best accuracy score:', best_model_acc)
                print('----------------------------')

                # 将相同的内容写入文件
                file.write('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥\n')
                file.write(f'model_iter: {model_iter}\n')
                file.write(f'f1 score: {f1}\n')
                file.write(f'accuracy score: {accuracy}\n')
                file.write('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥\n')
                file.write('----------------------------\n')
                file.write(f'now best model_iter {best_model_iter}\n')
                file.write(f'now best f1 score: {best_model_f1}\n')
                file.write(f'now best accuracy score: {best_model_acc}\n')
                file.write('----------------------------\n')

    return best_model_iter, best_model_f1, best_model_acc, all_f1, all_acc






def main(_):
    setting = Config()

    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    print("测试开始，上天保佑，结果如愿")
    tf.reset_default_graph()


    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑


# ceshi 完成后，我们重置默认图
    FLAGS.train = True  # 修改 FLAGS.train 的取值为 T

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("*************第二轮训练开始*****************")
    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("第二轮测试开始，上天保佑，结果如愿")

    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑

# ceshi 完成后，我们重置默认图
    FLAGS.train = True  # 修改 FLAGS.train 的取值为 T

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("*************第三轮训练开始*****************")
    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("第三轮测试开始，上天保佑，结果如愿")

    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑

# ceshi 完成后，我们重置默认图
    FLAGS.train = True  # 修改 FLAGS.train 的取值为 T

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("*************第四轮训练开始*****************")
    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("第四轮测试开始，上天保佑，结果如愿")

    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑

# ceshi 完成后，我们重置默认图
    FLAGS.train = True  # 修改 FLAGS.train 的取值为 T

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("*************第五轮训练开始*****************")
    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    tf.reset_default_graph()
    print("第五轮测试开始，上天保佑，结果如愿")

    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑




if __name__ == '__main__':
    tf.app.run()







