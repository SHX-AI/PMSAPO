import tensorflow as tf
# import tensorflow.contrib.rnn as rnn
# import tensorflow._api.v2.compat.v1 as tf
import numpy as np
from Settings import Config
from module import ff, multihead_attention, SigmoidAtt, ff2
from collections import defaultdict

import tensorflow as tf
import numpy as np
import datetime

print("521")


class MM:
    def __init__(self, is_training):
        self.temp = 'null'
        self.config = Config()
        self.att_dim = self.config.att_dim

        self.visual = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_visual_len, 709],
                                     name='visual')
        self.audio = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_audio_len, 33],
                                    name='audio')
        self.text = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_text_len, 768],
                                   name='text')
        self.label = tf.placeholder(dtype=tf.int32, shape=[self.config.batch_size], name='label')
        self.flag = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size], name='flag')

        visual = tf.layers.dense(self.visual, self.config.att_dim, use_bias=False)
        audio = tf.layers.dense(self.audio, self.config.att_dim, use_bias=False)
        text = tf.layers.dense(self.text, self.config.att_dim, use_bias=False)

        with tf.variable_scope('vv', reuse=tf.AUTO_REUSE):
            visual = multihead_attention(queries=visual, keys=visual, values=visual, num_heads=4, dropout_rate=0.2,
                                         training=is_training, causality=False)
            visual = ff(visual, num_units=[4 * self.config.att_dim, self.config.att_dim])

        with tf.variable_scope('aa', reuse=tf.AUTO_REUSE):
            audio = multihead_attention(queries=audio, keys=audio, values=audio, num_heads=4, dropout_rate=0.2,
                                        training=is_training, causality=False)
            audio = ff(audio, num_units=[4 * self.config.att_dim, self.config.att_dim])

        with tf.variable_scope('tt', reuse=tf.AUTO_REUSE):
            text = multihead_attention(queries=text, keys=text, values=text, num_heads=4, dropout_rate=0.2,
                                       training=is_training, causality=False)
            text = ff(text, num_units=[4 * self.config.att_dim, self.config.att_dim])

        max_len = max(visual.shape[1], audio.shape[1], text.shape[1])
        visual = tf.pad(visual, [[0, 0], [0, max_len - visual.shape[1]], [0, 0]])
        audio = tf.pad(audio, [[0, 0], [0, max_len - audio.shape[1]], [0, 0]])
        text = tf.pad(text, [[0, 0], [0, max_len - text.shape[1]], [0, 0]])

        enc_all = tf.concat([visual, audio, text], 1)
        with tf.variable_scope('all_modal', reuse=tf.AUTO_REUSE):
            enc_all = multihead_attention(queries=enc_all, keys=enc_all, values=enc_all, num_heads=4, dropout_rate=0.2,
                                          training=is_training, causality=False)
            enc_all = ff(enc_all, num_units=[4 * self.att_dim, self.att_dim])

        fm = enc_all
        enc_all = tf.add(enc_all, tf.concat([visual, audio, text], 1))
        enc_all = tf.layers.batch_normalization(enc_all)

        weights = tf.layers.dense(enc_all, units=3, activation=tf.nn.tanh)
        weights = tf.nn.softmax(weights, axis=2)

        visual_weight = weights[:, :visual.shape[1], 0:1]
        audio_weight = weights[:, visual.shape[1]:visual.shape[1] + audio.shape[1], 1:2]
        text_weight = weights[:, visual.shape[1] + audio.shape[1]:, 2:3]

        visual = visual * visual_weight
        audio = audio * audio_weight
        text = text * text_weight

        fvm = tf.concat([visual, fm], 1)
        fam = tf.concat([audio, fm], 1)
        ftm = tf.concat([text, fm], 1)

        fvPie = []
        for i in range(self.config.batch_size):
            fvPie.append(tf.concat(
                [fvm[i], tf.tile([[self.flag[i], self.flag[i], self.flag[i], self.flag[i]]], [tf.shape(fvm)[1], 1])],
                -1))
        fvPie = tf.stack(fvPie)

        faPie = []
        for i in range(self.config.batch_size):
            faPie.append(tf.concat(
                [fam[i], tf.tile([[self.flag[i], self.flag[i], self.flag[i], self.flag[i]]], [tf.shape(fam)[1], 1])],
                -1))
        faPie = tf.stack(faPie)

        ftPie = []
        for i in range(self.config.batch_size):
            ftPie.append(tf.concat(
                [ftm[i], tf.tile([[self.flag[i], self.flag[i], self.flag[i], self.flag[i]]], [tf.shape(ftm)[1], 1])],
                -1))
        ftPie = tf.stack(ftPie)

        fvPie_input = tf.reshape(fvPie, [9600, -1])
        fvPie_input = tf.layers.dense(fvPie_input, units=304)
        fvproj = tf.reshape(fvPie_input, [32, 300, 304])

        faPie = faPie[:, -300:, :]
        faPie_input = tf.reshape(faPie, [9600, -1])
        faPie_input = tf.layers.dense(faPie_input, units=304)
        faproj = tf.reshape(faPie_input, [32, 300, 304])

        with tf.variable_scope('all_weights', reuse=tf.AUTO_REUSE):
            Wr_wq = tf.get_variable('Wr_wq', [304, 1])
            Wm_wq = tf.get_variable('Wm_wq', [304, 304])
            Wu_wq = tf.get_variable('Wu_wq', [304, 304])

            W_l = tf.get_variable('W_l', [self.att_dim, self.config.class_num])
            b_l = tf.get_variable('b_l', [1, self.config.class_num])

            Wv = tf.get_variable('Wv', [self.config.class_num], initializer=tf.ones_initializer())
            Wa = tf.get_variable('Wa', [self.config.class_num], initializer=tf.ones_initializer())

        enc_vv_new = tf.convert_to_tensor(fvproj)
        enc_aa_new = tf.convert_to_tensor(faproj)
        enc_tt_new = tf.convert_to_tensor(ftPie)

        outputs_en_vv = SigmoidAtt(enc_vv_new, Wr_wq, Wm_wq, Wu_wq)
        outputs_en_aa = SigmoidAtt(enc_aa_new, Wr_wq, Wm_wq, Wu_wq)
        outputs_en_tt = SigmoidAtt(enc_tt_new, Wr_wq, Wm_wq, Wu_wq)

        ouput_label = tf.one_hot(self.label, self.config.class_num)
        temp_new_vv = outputs_en_vv
        temp_new_vv = tf.layers.dense(temp_new_vv, self.config.att_dim, use_bias=False)
        output_res_vv = tf.add(tf.matmul(temp_new_vv, W_l), b_l)

        temp_new_aa = outputs_en_aa
        temp_new_aa = tf.layers.dense(temp_new_aa, self.config.att_dim, use_bias=False)
        output_res_aa = tf.add(tf.matmul(temp_new_aa, W_l), b_l)

        temp_new_tt = outputs_en_tt
        temp_new_tt = tf.layers.dense(temp_new_tt, self.config.att_dim, use_bias=False)
        output_res_tt = tf.add(tf.matmul(temp_new_tt, W_l), b_l)

        output_res_vv = tf.multiply(output_res_vv, Wv)
        output_res_aa = tf.multiply(output_res_aa, Wa)

        output_res = tf.add(output_res_vv, tf.add(output_res_aa, output_res_tt))

        # 因为投稿的周期太长，在这期间我们对代码进行了优化，
        # 用上面的add方法代替论文中的concat操作我们发现模型性能会更稳定并且效果更好，所以大家可以用上面的方法进行复现和改进
        # 祝大家科研顺遂
        # Due to the long submission cycle, we optimized the code during this period.
        # We found that replacing the `concat` operation in the paper with the `add` method mentioned above can lead to more stable model performance and better results. Therefore, you can use the method described above for reproduction and improvement.
        # Wish you all a smooth journey in scientific research.

        # output_res1 = tf.concat([output_res_aa, output_res_tt, output_res_vv], axis=-1)
        # output_res = tf.reshape(output_res1, [-1, 3, self.config.class_num])
        # output_res = tf.reduce_mean(output_res, axis=1)

        self.prob = tf.nn.softmax(output_res)

        with tf.name_scope('loss'):
            loss = tf.reduce_sum(tf.nn.softmax_cross_entropy_with_logits(logits=output_res, labels=ouput_label))
            self.loss = loss
            self.l2_loss = tf.contrib.layers.apply_regularization(regularizer=tf.contrib.layers.l2_regularizer(0.0001),
                                                                  weights_list=[W_l, b_l])
            self.total_loss = self.loss + self.l2_loss

            # 在MM类的最后添加这个方法

    def get_trainable_vars(self):
        return tf.trainable_variables()
